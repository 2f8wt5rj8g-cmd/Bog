# BFG Calibration iOS — 自动编译

## 使用方法

### 第一步：建 GitHub 仓库

1. 打开 https://github.com/new
2. 仓库名填 `bfg-calibration-ios`，选 **Private**（私有）
3. 不要勾选 README/gitignore
4. 创建后把本文件夹所有文件 push 上去：

```bash
cd BFG-iOS-build
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/你的用户名/bfg-calibration-ios.git
git push -u origin main
```

### 第二步：等自动编译

push 后 GitHub 会自动触发云端 Mac 编译：

1. 打开仓库页面 → 点 **Actions** 标签
2. 看到黄色圆点 = 正在编译
3. 变绿勾 = 编译成功（约 3-5 分钟）

### 第三步：下载 IPA

1. 点进成功的 workflow → 底部 **Artifacts** 区域
2. 下载 `BFGCalibration-unsigned`
3. 解压得到 `BFGCalibration.ipa`

### 第四步：装到 iPhone

IPA 是未签名的，用以下任一工具签名安装：

| 工具 | 说明 |
|---|---|
| **Sideloadly** | 电脑端，用 Apple ID 免费签名，7 天有效 |
| **AltStore** | 电脑端，后台自动续签 |
| **TrollStore** | 如果你的 iOS 版本支持（15.0-16.6.1），可永久签名 |

## 文件结构

```
├── .github/workflows/build-ipa.yml   # GitHub Actions 编译脚本
├── project.yml                        # XcodeGen 工程定义
└── BFGCalibration/
    ├── BFGCalibrationApp.swift
    ├── ContentView.swift
    ├── BFGEncryption.swift           # AES-CTR + SHA1
    ├── BFGProtocol.swift             # 蓝牙帧
    ├── BFGBleManager.swift           # CoreBluetooth
    ├── Info.plist
    └── Assets.xcassets/
```

## 改代码后重新编译

改完 .swift 文件后 push，Actions 会自动重新编译出新版 IPA。
