//
//  BFGEncryption.swift
//  BFGCalibration iOS
//  AES-128-CTR 加解密 + SHA1 密钥派生（从安卓版 Encryption2 移植）
//

import Foundation
import CommonCrypto

enum BFGCryptoError: Error {
    case shortFrame
    case invalidKey
    case aesFailure
}

final class BFGEncryption {

    /// 安卓版 DATA_BASIC 静态种子
    static let dataBasic = Data(hex: "97CFB802844143DE56002B3B34780A5D")!

    private var initialKey: Data       // 由设备名派生
    private var sessionKey: Data?      // SN 交换后建立
    private var authParam: Data?

    // MARK: - 初始化

    /// 用蓝牙设备名构造
    init(deviceName: String) {
        let nameBytes = deviceName.data(using: .utf8) ?? Data()
        self.initialKey = BFGEncryption.deriveKey(pad16(nameBytes), BFGEncryption.dataBasic)
    }

    // MARK: - 密钥派生

    /// SHA1(pad16(a) + pad16(b)) 取前 16 字节
    static func deriveKey(_ a: Data, _ b: Data) -> Data {
        var combined = pad16(a)
        combined.append(pad16(b))
        var digest = [UInt8](repeating: 0, count: Int(CC_SHA1_DIGEST_LENGTH))
        combined.withUnsafeBytes { buf in
            CC_SHA1(buf.baseAddress, CC_LONG(combined.count), &digest)
        }
        return Data(digest.prefix(16))
    }

    /// 补零到 16 字节
    static func pad16(_ data: Data) -> Data {
        var out = Data(count: 16)
        let n = min(data.count, 16)
        out.replaceSubrange(0..<n, with: data.prefix(n))
        return out
    }

    // MARK: - AES-128-ECB

    /// AES-128-ECB NoPadding 加密/解密（同一函数，ECB 对称）
    static func aesECB(key: Data, _ data: Data) throws -> Data {
        guard key.count == 16 else { throw BFGCryptoError.invalidKey }
        // 数据长度必须是 16 的倍数（安卓版 NoPadding，调用方自行处理）
        let padded = data.count % 16 == 0 ? data : data + Data(count: 16 - data.count % 16)
        var out = Data(count: padded.count)
        var status: CCCryptorStatus = 0
        out.withUnsafeMutableBytes { outBuf in
            padded.withUnsafeBytes { inBuf in
                key.withUnsafeBytes { keyBuf in
                    status = CCCrypt(
                        CCOperation(kCCEncrypt),
                        CCAlgorithm(kCCAlgorithmAES),
                        CCOptions(kCCOptionECBMode),
                        keyBuf.baseAddress, 16,
                        nil,
                        inBuf.baseAddress, padded.count,
                        outBuf.baseAddress, out.count,
                        nil
                    )
                }
            }
        }
        guard status == kCCSuccess else { throw BFGCryptoError.aesFailure }
        return out
    }

    // MARK: - CTR 模式

    /// 构造 13 字节 nonce：前 10 字节固定 + 后 3 字节计数器大端
    static func nonce(counter: UInt32) -> Data {
        var n = Data(count: 13)
        // 前 10 字节在安卓版中是 initialKey 的前 10 字节（由调用方传入 seed）
        // 这里由调用方通过 encryptCTR 传入 seed
        return n
    }

    /// CTR 加解密（对称）
    /// - Parameters:
    ///   - key: 16 字节密钥
    ///   - seed: nonce 前 10 字节（通常是 initialKey 前 10 字节）
    ///   - counter: 计数器
    ///   - payload: 明文/密文
    static func cryptCTR(key: Data, seed: Data, counter: UInt8, payload: Data) throws -> Data {
        // 构造 16 字节块：[seed(10)] [counter(3 bytes big-endian)] [0x00 0x00]
        // 安卓版 nonce 13 字节，补到 16 字节后做 ECB-AES 得到 keystream
        var block = Data(count: 16)
        let seedLen = min(seed.count, 10)
        block.replaceSubrange(0..<seedLen, with: seed.prefix(seedLen))
        // counter 占 3 字节（位置 10,11,12）
        block[10] = counter
        block[11] = 0
        block[12] = 0

        let keystream = try aesECB(key: key, block)

        // XOR payload with keystream (按字节异或，长度对齐)
        var result = Data(count: payload.count)
        for i in 0..<payload.count {
            let ksByte = keystream[i % 16]
            result[i] = payload[i] ^ ksByte
        }
        return result
    }

    // MARK: - 会话

    /// SN 交换后建立会话密钥
    func establishSession(authParam: Data, password: Data) {
        self.authParam = authParam
        self.sessionKey = BFGEncryption.deriveKey(authParam, BFGEncryption.pad16(password))
    }

    /// 名称会话（预通信阶段）
    func establishNameSession(_ challenge: Data) {
        // 安卓版：用 initialKey 加密 challenge 作为名称会话响应
        // 实际逻辑在 BfgBleClient 中组合，这里保留钩子
    }

    // MARK: - 预通信加解密

    /// 加密预通信帧（用 initialKey）
    func encryptPreComm(_ plain: Data) throws -> Data {
        guard plain.count >= 9 else { throw BFGCryptoError.shortFrame }
        // 安卓版：帧头 5A A5 明文，从第 3 字节开始加密
        var frame = Data(plain.prefix(2)) // 5A A5 明文
        let body = plain.subdata(in: 2..<plain.count)
        let encrypted = try BFGEncryption.cryptCTR(
            key: initialKey,
            seed: initialKey.prefix(10),
            counter: body[0],
            payload: body
        )
        frame.append(encrypted)
        return frame
    }

    /// 解密预通信帧
    func decryptPreComm(_ frame: Data) throws -> Data {
        guard frame.count >= 9 else { throw BFGCryptoError.shortFrame }
        var plain = Data(frame.prefix(2))
        let body = frame.subdata(in: 2..<frame.count)
        let decrypted = try BFGEncryption.cryptCTR(
            key: initialKey,
            seed: initialKey.prefix(10),
            counter: body[0],
            payload: body
        )
        plain.append(decrypted)
        return plain
    }

    // MARK: - SN 帧加解密（会话密钥）

    /// 加密 SN 数据帧
    func encryptSn(_ payload: Data, counter: UInt8) throws -> Data {
        guard let key = sessionKey else { throw BFGCryptoError.shortFrame }
        return try BFGEncryption.cryptCTR(
            key: key,
            seed: initialKey.prefix(10),
            counter: counter,
            payload: payload
        )
    }

    /// 解密 SN 数据帧
    func decryptSn(_ frame: Data, counter: UInt8) throws -> Data {
        guard let key = sessionKey else { throw BFGCryptoError.shortFrame }
        return try BFGEncryption.cryptCTR(
            key: key,
            seed: initialKey.prefix(10),
            counter: counter,
            payload: frame
        )
    }
}

// MARK: - Data hex 扩展

extension Data {
    init?(hex: String) {
        let clean = hex.replacingOccurrences(of: " ", with: "")
        guard clean.count % 2 == 0 else { return nil }
        self.init(capacity: clean.count / 2)
        var start = clean.startIndex
        for _ in 0..<clean.count / 2 {
            let end = clean.index(start, offsetBy: 2)
            guard let byte = UInt8(clean[start..<end], radix: 16) else { return nil }
            self.append(byte)
            start = end
        }
    }

    func hexString() -> String {
        map { String(format: "%02X", $0) }.joined()
    }
}
